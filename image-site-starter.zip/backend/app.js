const express = require('express');
const cors = require('cors');
const app = express();
const imageRoutes = require('./routes/images');
app.use(cors());
app.use(express.json());
app.use('/api/images', imageRoutes);
app.listen(3001, () => console.log('Backend running on port 3001'));