const db = require('../config/db');

const getImages = (req, res) => {
  db.query('SELECT * FROM images ORDER BY created_at DESC LIMIT 50', (err, results) => {
    if (err) return res.status(500).json({ error: err });
    res.json(results);
  });
};

module.exports = { getImages };